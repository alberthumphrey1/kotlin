fun main(args: Array<String>) {
    var x: Int
    var y:Double
    var z:Float

    var xConverted:String
    var yConverted:String
    var zConverted:String

    x = 40
    y = 50.0
    z= 90.0f
    println(x + y + z)

    xConverted = x.toString()
    yConverted = y.toString()
    zConverted = z.toString()
    println(xConverted + yConverted + zConverted)
}