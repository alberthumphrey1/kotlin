fun main(args: Array<String>) {
    println("Welcome to Kotlin")
    println("Good morning")

    var x:Int
    var y:Double
    var z:Float
    var name:String
    var abc:Char

    val p:Double
    val q:Int

    x = 10
    y = 20.0
    name = "King"
    abc = 'a'
    z = 78.5f

}