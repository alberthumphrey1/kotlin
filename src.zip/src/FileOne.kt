fun main(args: Array<String>) {
    println("Welcome to Kotlin")
}