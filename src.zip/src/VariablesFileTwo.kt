fun main(args: Array<String>) {
    var x:Int = 20
    var y = 20 //
    var b:String = "King"
    var c:Double = 98.6
    println(x+c)
}